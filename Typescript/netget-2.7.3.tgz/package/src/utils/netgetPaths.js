import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';

const SOURCE_OR_DIST_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PACKAGE_DIR = path.resolve(SOURCE_OR_DIST_DIR, '..');

function tryEnsureDir(dir) {
    try {
        fs.mkdirSync(dir, { recursive: true });
        return dir;
    } catch (error) {
        return null;
    }
}

function canWriteToDir(dir) {
    const ensuredDir = tryEnsureDir(dir);
    if (!ensuredDir) {
        return false;
    }

    const testPath = path.join(ensuredDir, '.netget-write-test');
    try {
        const handle = fs.openSync(testPath, 'a');
        fs.closeSync(handle);
        fs.unlinkSync(testPath);
        return true;
    } catch (error) {
        try {
            fs.unlinkSync(testPath);
        } catch {
            // ignore cleanup errors
        }
        return false;
    }
}

function resolveDataDir() {
    const osName = os.platform();
    const homeDir = os.homedir();

    if (osName === 'linux') {
        const optPath = '/opt/.get';
        if (canWriteToDir(optPath)) {
            return optPath;
        }

        const homePath = path.join(homeDir, '.get');
        if (canWriteToDir(homePath)) {
            return homePath;
        }
    } else if (osName === 'darwin') {
        const homePath = path.join(homeDir, '.get');
        if (canWriteToDir(homePath)) {
            return homePath;
        }
    } else if (osName === 'win32') {
        const appDataPath = process.env.APPDATA || path.join(homeDir, 'AppData', 'Roaming');
        const netgetPath = path.join(appDataPath, 'NetGet');
        if (canWriteToDir(netgetPath)) {
            return netgetPath;
        }
    }

    throw new Error('Unable to determine a writable NetGet data directory.');
}

let DATA_DIR = null;

function resolveDataDirOnce() {
    // Allow override via environment (used in tests and for cross-process
    // integrations such as the Monad → NetGet usage bridge).
    // The env var takes priority over the cached platform default so that
    // both test isolation and runtime overrides work without restarting.
    if (process.env.NETGET_DATA_DIR) {
        return process.env.NETGET_DATA_DIR;
    }
    if (!DATA_DIR) {
        DATA_DIR = resolveDataDir();
    }
    return DATA_DIR;
}

export function getNetgetDataDir() {
    return resolveDataDirOnce();
}

export function getNetgetPackageRootDir() {
    return PACKAGE_DIR;
}

export function getHtmlRootDir() {
    const htmlRoot = path.join(getNetgetDataDir(), 'html');
    tryEnsureDir(htmlRoot);
    return htmlRoot;
}
